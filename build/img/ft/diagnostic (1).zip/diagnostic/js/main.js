document.addEventListener('DOMContentLoaded', () => {
    anime({
        targets: '.header__image',
        translateY: [-200, 0],
        easing: 'easeOutExpo',
        duration: 1500,
        delay: 1000,
        opacity: [0, 1],
    })
    anime({
        targets: '.header__title',
        translateY: [-300, 0],
        easing: 'easeOutExpo',
        duration: 1500,
        delay: 1100,
        opacity: [0, 1],
    })
    anime({
        targets: '.adv__flex',
        translateY: [100, 0],
        easing: 'easeOutExpo',
        duration: 1500,
        delay: (el, i) => {
            return 1100 + 100 * i;
        },
        opacity: [0, 1],
    })
    anime({
        targets: '.image__flex .img__opium',
        translateX: [100, 0],
        easing: 'easeOutExpo',
        duration: 1500,
        delay: 1200,
        opacity: [0, 1],
    })
    anime({
        targets: '.opium__text',
        translateY: [200, 0],
        easing: 'easeOutExpo',
        duration: 1500,
        delay: 1100,
        opacity: [0, 1],
    })
    anime({
        targets: '.network-vk',
        translateX: [-150, 0],
        easing: 'easeOutExpo',
        duration: 1500,
        delay: 1100,
        opacity: [0, 1],
    })
    anime({
        targets: '.network-inst',
        translateX: [150, 0],
        easing: 'easeOutExpo',
        duration: 1500,
        delay: 1100,
        opacity: [0, 1],
    })
    anime({
        targets: '.header__button',
        translateY: [150, 0],
        easing: 'easeOutExpo',
        duration: 1500,
        delay: 1100,
        opacity: [0, 1],
    })
    anime({
        targets: '.advan__title',
        translateY: [-50, 0],
        easing: 'easeOutExpo',
        duration: 1800,
        delay: 1000,
        opacity: [0, 1],
    })
    anime({
        targets: '.card__box',
        translateX: [50, 0],
        easing: 'easeOutExpo',
        duration: 1800,
        delay: 1000,
        opacity: [0, 1],
    })
})