$(document).ready(function() {
    $(".owl-carousel").owlCarousel({
        items: 1
    });
});